import Navbar from "./components/Navbar";
import Search from "./components/Search";
import ShipmentDetails from "./components/ShipmentDetails";
import { ItemsProvider } from "./context/ItemContext";
function App() {
  return (
    <ItemsProvider>
      <div className="container px-16 mx-auto ">
        <Navbar />
        <div className="flex justify-center my-9">
          <Search />
        </div>

        <ShipmentDetails />
      </div>
    </ItemsProvider>
  );
}

export default App;
