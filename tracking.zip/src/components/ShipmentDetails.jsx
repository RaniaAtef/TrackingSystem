import { useContext, useEffect, useState } from "react";
import axios from "axios";
import { useSearchParams } from "react-router-dom";
import ItemsContext from "../context/ItemContext";

const ShipmentDetails = () => {
  //   const [shipmentDetails, setShipmentDetails] = useState([]);
  const [searchParams, setSearchParams] = useSearchParams();
  const { ShipmentDetails, setShipmentDetails } = useContext(ItemsContext);
  const itemNum = searchParams.get("item");
  console.log(ShipmentDetails);

  useEffect(() => {
    async function getData() {
      if (itemNum) {
        try {
          console.log(itemNum);

          const { data } = await axios.get(
            `https://tracking.bosta.co/shipments/track/${itemNum}`
            //   "https://tracking.bosta.co/shipments/track/13737343"
          );
          console.log(data, "dataaaa");
          setShipmentDetails(data);
        } catch (err) {
          setShipmentDetails({});
        }
      }
    }
    getData();
  }, [itemNum]);
  return (
    <div>
      <div className="overflow-x-auto">
        <table className="table table-xs">
          <thead>
            <tr>
              <th></th>
              <th>Branch</th>
              <th>Date</th>
              <th>Time</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            {ShipmentDetails.TransitEvents?.map((item) => (
              <tr>
                <td></td>
                <td>{item.hub ? item.hub : "-"}</td>
                <td>{item.timestamp}</td>
                <td>{item.timestamp}</td>
                <td>{item.state}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ShipmentDetails;
